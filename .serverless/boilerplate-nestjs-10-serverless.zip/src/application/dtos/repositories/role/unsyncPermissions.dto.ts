export interface UnsyncPermissionsRepositoryInputDto {
  roleId: number;
  permissionIds: number[];
}
