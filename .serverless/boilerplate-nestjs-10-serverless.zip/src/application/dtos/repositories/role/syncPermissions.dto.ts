export interface SyncPermissionsRepositoryInputDto {
  roleId: number;
  permissionIds: number[];
}
