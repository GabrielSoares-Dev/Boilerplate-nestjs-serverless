export interface GenerateTokenServiceInputDto {
  id: number;
  name: string;
  email: string;
  phoneNumber: string;
  // role: string;
  // permissions: string[];
}
