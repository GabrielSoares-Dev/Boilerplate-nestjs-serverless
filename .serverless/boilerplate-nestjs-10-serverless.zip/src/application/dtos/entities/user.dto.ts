export interface UserEntityInputDto {
  name: string;
  email: string;
  phoneNumber: string;
  password: string;
}
