export interface RoleEntityInputDto {
  name: string;
  description?: string;
}
