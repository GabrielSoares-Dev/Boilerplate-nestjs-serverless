export interface PermissionEntityInputDto {
  name: string;
  description?: string;
}
