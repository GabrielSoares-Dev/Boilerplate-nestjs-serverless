export interface CreateUserUseCaseInputDto {
  name: string;
  email: string;
  phoneNumber: string;
  password: string;
}
