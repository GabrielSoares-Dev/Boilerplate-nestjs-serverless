export interface LogoutUseCaseInputDto {
  token: string;
}
