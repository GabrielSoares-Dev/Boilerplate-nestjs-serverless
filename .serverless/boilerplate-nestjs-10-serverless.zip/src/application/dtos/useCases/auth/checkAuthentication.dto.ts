export interface CheckAuthenticationUseCaseInputDto {
  token?: string;
}
