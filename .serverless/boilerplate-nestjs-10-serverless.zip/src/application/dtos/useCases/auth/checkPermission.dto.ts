export interface CheckPermissionUseCaseInputDto {
  userPermissions: string[];
  expectedPermission: string;
}
