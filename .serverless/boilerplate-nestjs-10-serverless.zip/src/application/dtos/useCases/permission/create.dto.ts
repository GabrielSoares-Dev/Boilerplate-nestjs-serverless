export interface CreatePermissionUseCaseInputDto {
  name: string;
  description?: string;
}
