export interface UpdateUseCaseInputDto {
  id: number;
  name?: string;
  description?: string;
}
