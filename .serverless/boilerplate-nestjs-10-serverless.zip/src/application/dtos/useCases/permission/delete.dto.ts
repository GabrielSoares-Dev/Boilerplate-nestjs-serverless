export interface DeletePermissionUseCaseInputDto {
  id: number;
}
