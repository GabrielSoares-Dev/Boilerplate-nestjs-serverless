export interface SyncPermissionsUseCaseInputDto {
  role: string;
  permissions: string[];
}
