export interface CreateRoleUseCaseInputDto {
  name: string;
  description?: string;
}
