export interface UnyncPermissionsUseCaseInputDto {
  role: string;
  permissions: string[];
}
