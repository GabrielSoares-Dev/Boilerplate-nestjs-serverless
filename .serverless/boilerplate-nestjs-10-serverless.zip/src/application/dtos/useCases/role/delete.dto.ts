export interface DeleteRoleUseCaseInputDto {
  id: number;
}
