export enum Role {
  ADMIN = 'admin',
}
